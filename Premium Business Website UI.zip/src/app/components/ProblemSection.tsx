import { motion } from 'motion/react';
import { AlertTriangle, DollarSign, HelpCircle } from 'lucide-react';

export function ProblemSection() {
  const problems = [
    {
      icon: AlertTriangle,
      title: 'Proveedores Poco Confiables',
      description: 'Encontrar proveedores confiables en China puede ser desafiante y riesgoso.',
    },
    {
      icon: DollarSign,
      title: 'Riesgo de Perder Dinero',
      description: 'Sin experiencia, las importaciones pueden generar pérdidas financieras y retrasos.',
    },
    {
      icon: HelpCircle,
      title: 'Falta de Experiencia',
      description: 'El comercio internacional requiere conocimiento y experiencia para tener éxito.',
    },
  ];

  return (
    <section className="py-20 bg-[#0A2E3D]">
      <div className="max-w-7xl mx-auto px-6">
        <motion.h2
          className="text-4xl font-bold text-white text-center mb-4"
          style={{ fontFamily: 'Poppins, sans-serif' }}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          Desafíos Comunes de Importación
        </motion.h2>
        <motion.p
          className="text-xl text-[#B0C4CC] text-center mb-16 max-w-2xl mx-auto"
          style={{ fontFamily: 'Inter, sans-serif' }}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          Entendemos los obstáculos que impiden a las empresas importar con éxito
        </motion.p>

        <div className="grid md:grid-cols-3 gap-8">
          {problems.map((problem, index) => {
            const Icon = problem.icon;
            return (
              <motion.div
                key={index}
                className="bg-[#0D3A4A] rounded-2xl p-8 hover:bg-[#0D3A4A]/80 transition-all duration-300 group"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                whileHover={{ y: -10 }}
              >
                <div className="bg-[#00C2FF]/10 w-16 h-16 rounded-xl flex items-center justify-center mb-6 group-hover:bg-[#00C2FF]/20 transition-colors">
                  <Icon className="w-8 h-8 text-[#00C2FF]" />
                </div>
                <h3
                  className="text-2xl font-bold text-white mb-4"
                  style={{ fontFamily: 'Poppins, sans-serif' }}
                >
                  {problem.title}
                </h3>
                <p className="text-[#B0C4CC]" style={{ fontFamily: 'Inter, sans-serif' }}>
                  {problem.description}
                </p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}